<?php
$title = 'Index';
require_once 'includes/header.php';
?>

<h2 class="text-center"> Registration for IT Conference </h1>

<form>
    <div>
        <label for="fname">First name:</label><br>
            <input type="text" id="fname" name="fname"><br>
                <label for="lname">Last name:</label><br>
                    <input type="text" id="lname" name="lname">
    </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Example file input</label>
        <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  <div class="form-group">
    <label for="exampleInputDateBirth1">Date of Birth</label>
        <input type="date" value="2023-30-03">
  </div>
    <div class="form-group">
        <div class="col-md-3 mb-3">
            <label for="validationDefault04">State</label>
                <select class="custom-select" id="validationDefault04" required>
                    <option selected disabled value=""> Choose...</option>
                    <option> Database Admin </option>
                    <option> Software Developer </option>
                    <option> Web Administrator </option>
                    <option> Graphic Designer </option>
                    <option> Animator/ Cartoonist </option>
                </select>
        </div>
    </div>  
        <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php require_once 'includes/footer.php' ?>